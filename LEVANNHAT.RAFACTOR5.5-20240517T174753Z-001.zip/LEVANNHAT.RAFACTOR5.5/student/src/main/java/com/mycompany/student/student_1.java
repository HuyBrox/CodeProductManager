/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.student;

/**
 *
 * @author levannhat
 */
class Student {
    private final int id;
    private final String name;
    private final int classID;
    private final String birthday;
    private final String address;
    private final String phone;

    public Student(int id, String name, int classID, String birthday, String address, String phone) {
        this.id = id;
        this.name = name;
        this.classID = classID;
        this.birthday = birthday;
        this.address = address;
        this.phone = phone;
    }

    public void display() {
        System.out.println("Thông tin sinh viên:");
        System.out.println("ID: " + id);
        System.out.println("Họ và tên: " + name);
        System.out.println("Lớp: " + classID);
        System.out.println("Ngày sinh: " + birthday);
        System.out.println("Địa chỉ: " + address);
        System.out.println("Số điện thoại: " + phone);
    }

    public static void main(String[] args) {
       Student Student = new Student(1, "Nguyễn Văn A", 10, "1999-01-01", "Hà Nội", "0912345678");
       Student.display();
    }
}


    

